const App = () => {
  return (
    <Template>
      <h1>Main content</h1>
    </Template>
  );
}

ReactDOM.render(
  <App />,
  document.getElementById('root')
);