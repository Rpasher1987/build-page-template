const App = () => {
  return (
    <Template>
      <h1>Press page</h1>
    </Template>
  );
}

ReactDOM.render(
  <App />,
  document.getElementById('root')
);